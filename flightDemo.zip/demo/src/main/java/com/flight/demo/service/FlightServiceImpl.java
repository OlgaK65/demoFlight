package com.flight.demo.service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;

import org.springframework.stereotype.Service;

import com.flight.demo.domain.Flight;

@Service
public class FlightServiceImpl implements FlightService {
	
	@Override
	public Flight getFlight(String id) {
		try(BufferedReader in = new BufferedReader(new FileReader("flights.csv")) ) {
			String str = in.readLine();
			
			while(str != null) {
				String[] flightData = str.split(",");
				if(flightData[0].compareTo(id) == 0) 
					return new Flight(id, flightData[1], flightData[2]);
			
			     str = in.readLine();
			}			
		} 
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return null;	
	}
	
	@Override
	public Flight addFlight(Flight flight) {
		try(BufferedWriter out = new BufferedWriter(new FileWriter("flights.csv")) ){
			out.append(flight.toString());
		}
		catch(Exception e) {
			e.printStackTrace();
			return null;
		}
		
		return flight;	
	}

	
	
}
