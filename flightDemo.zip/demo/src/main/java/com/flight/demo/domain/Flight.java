package com.flight.demo.domain;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor

public class Flight implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String flightId;
	private String arrival;
	private String departure;
	private Boolean success;
	
	public Flight(String flightId,String arrival,String departure ) {
		this.flightId = flightId;
		this.arrival = arrival;
		this.departure = departure;
	}
	
	public String ToString() {
		return flightId + ", " + arrival + ", " + departure + ", " + success;
	}
}
