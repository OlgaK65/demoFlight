package com.flight.demo.service;

import com.flight.demo.domain.Flight;

public interface FlightService {
	public Flight getFlight(String id);
	public Flight addFlight(Flight flight);
}
