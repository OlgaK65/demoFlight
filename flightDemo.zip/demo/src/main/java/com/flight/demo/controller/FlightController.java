package com.flight.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.flight.demo.domain.Flight;
import com.flight.demo.service.FlightService;

@RestController
public class FlightController {
	
	@Autowired
	FlightService service;
	
	@GetMapping("/get_flight")
	public Flight getFlight(@PathVariable String flightId) {
		return service.getFlight(flightId);
	}
	
	@PostMapping("/post_fight")
	public Flight addFlight(@RequestBody Flight flight) {
		return service.addFlight(flight);
	}

}
